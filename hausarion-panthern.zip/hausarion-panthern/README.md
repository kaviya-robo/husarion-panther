# Hausarion Panthern

4-wheel differential-drive robot in ROS 2 Humble + Gazebo Fortress,
with 2D lidar, A* path planning (configurable start/goal) and a
lidar-safety follower with replan + un-wedge escape.

## Layout

- `final_urdf/` — ROS 2 package (URDF, meshes, worlds, launch, config, planner)
- `scripts/teleop_custom.py` — keyboard drive: `i` forward, `j` reverse,
  `k` rotate left, `l` rotate right, `s` stop, `q` quit (publishes `/cmd_vel`)
- `scripts/drive_robot.py` — one-shot moves: `forward|back|left|right|circle|square`

## Requirements

- Ubuntu 22.04, ROS 2 Humble
- `ros_gz_sim`, `ros_gz_bridge`, `robot_state_publisher`, `rviz2`

## Build

```bash
mkdir -p ~/ros2_ws/src
cp -r final_urdf ~/ros2_ws/src/
cd ~/ros2_ws
colcon build --packages-select final_urdf
source /opt/ros/humble/setup.bash
source ~/ros2_ws/install/setup.sh   # (this workspace uses setup.sh)
```

## Run: manual drive (empty world)

Terminal 1:
```bash
source /opt/ros/humble/setup.bash
source ~/ros2_ws/install/setup.sh
ros2 launch final_urdf gazebo.launch.py
```
Terminal 2:
```bash
python3 scripts/teleop_custom.py   # press i/j/k, q to quit
# or: python3 scripts/drive_robot.py forward
```

## Run: autonomous path planning (lidar + A*)

One terminal (do NOT run teleop at the same time — single `/cmd_vel` driver only):

```bash
source /opt/ros/humble/setup.bash
source ~/ros2_ws/install/setup.sh
ros2 launch final_urdf path_planning.launch.py goal_x:=4.5 goal_y:=4.5 rviz:=false
```

- Start pose: robot spawns at `(0, 0)` (`-x/-y` in `path_planning.launch.py`,
  planner `start_x/start_y` params).
- End point: `goal_x`, `goal_y` launch args (default `4.5, 4.5`).
- World: `final_urdf/worlds/path_planning_world.sdf` (14x14 m, 4 obstacles).
- Topics: `/scan` (lidar), `/map`, `/planned_path`, `/path_markers`,
  `/odom`, `/cmd_vel`, `/replan`.
- Follower: waypoint tracking + lidar safety stop + replan on block +
  back-up-and-turn escape when wedged.

## Tuning notes (learned the hard way)

- `config/bridge.yaml`: lidar GZ topic is `/scan` (not the world-scoped path).
- `urdf/final_robot.urdf`: realistic masses (CAD import was 161 kg),
  joint effort 100 / damping 0.05, wheels lowered 16 mm for real contact,
  DiffDrive left/right lists assigned by physical side (base roll puts
  `*_left` joints on world −Y).
- `launch/path_planning.launch.py`: `inflation_radius` 0.75 (robot is
  1.19 m wide — 0.55 planned paths through un-fittable gaps), gentle
  `max_angular_vel` 0.6 to limit spin scrub, spawn `-z 0.38` (no drop bounce).
- `final_urdf/path_follower.py`: monotonic waypoint progress (no ping-pong),
  block/un-wedge escape with replan.
