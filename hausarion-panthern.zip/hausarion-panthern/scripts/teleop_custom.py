#!/usr/bin/env python3
"""Custom keyboard teleop for my_robot (final_urdf).

Your mapping:
  i = forward
  j = reverse (backward)
  k = rotate left in place
  l = rotate right in place (added for symmetry)
  u = forward + left, o = forward + right
  s / space = stop
  q / Ctrl-C = quit

Publishes geometry_msgs/Twist on /cmd_vel at 10 Hz (bridged to
/model/my_robot/cmd_vel in Gazebo by final_urdf gazebo.launch.py).

Usage:
  1. Launch sim (if not already running):
       source /opt/ros/humble/setup.bash
       source ~/ros2_ws/install/setup.sh
       ros2 launch final_urdf gazebo.launch.py
  2. In another terminal, run this:
       python3 ~/teleop_custom.py
  3. Press keys, q to quit.
"""
import select
import sys
import termios
import tty

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

LINEAR_SPEED = 0.4
ANGULAR_SPEED = 0.8

KEY_BINDINGS = {
    'i': (LINEAR_SPEED, 0.0),       # forward
    'j': (-LINEAR_SPEED, 0.0),      # reverse / backward
    'k': (0.0, ANGULAR_SPEED),      # rotate left
    'l': (0.0, -ANGULAR_SPEED),     # rotate right
    'u': (LINEAR_SPEED, ANGULAR_SPEED),
    'o': (LINEAR_SPEED, -ANGULAR_SPEED),
    's': (0.0, 0.0),
    ' ': (0.0, 0.0),
}

HELP = """Custom teleop - my_robot
  i = forward      j = reverse/backward
  k = rotate left  l = rotate right
  u = forward-left o = forward-right
  s / SPACE = stop  q = quit
Press keys in this terminal.
"""


def get_key(settings, timeout=0.1):
    tty.setraw(sys.stdin.fileno())
    rlist, _, _ = select.select([sys.stdin], [], [], timeout)
    if rlist:
        key = sys.stdin.read(1)
    else:
        key = ''
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    return key


def main():
    settings = termios.tcgetattr(sys.stdin)
    rclpy.init()
    node = Node('teleop_custom')
    pub = node.create_publisher(Twist, '/cmd_vel', 10)

    linear, angular = 0.0, 0.0
    print(HELP)
    try:
        while rclpy.ok():
            key = get_key(settings)
            if key == 'q' or key == '\x03':  # q or Ctrl-C
                break
            if key in KEY_BINDINGS:
                linear, angular = KEY_BINDINGS[key]
                print(f'key={key!r} -> linear={linear:.1f} angular={angular:.1f}')
            # always publish current cmd at ~10Hz so DiffDrive doesn't timeout
            msg = Twist()
            msg.linear.x = float(linear)
            msg.angular.z = float(angular)
            pub.publish(msg)
            rclpy.spin_once(node, timeout_sec=0.0)
    except KeyboardInterrupt:
        pass
    finally:
        # stop robot
        pub.publish(Twist())
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
        node.destroy_node()
        rclpy.shutdown()
        print('\nStopped robot, quit.')


if __name__ == '__main__':
    main()
