#!/usr/bin/env python3
"""Drive my_robot in Gazebo Fortress via ROS 2 Humble.
Topic: /model/my_robot/cmd_vel (bridged to Gazebo DiffDrive)
Usage:
  python3 drive_robot.py forward   # drive forward 3s
  python3 drive_robot.py back      # drive backward 3s
  python3 drive_robot.py left      # turn left in place 3s
  python3 drive_robot.py right     # turn right in place 3s
  python3 drive_robot.py circle    # drive circle 5s
  python3 drive_robot.py square    # drive 1m square
"""
import sys
import time
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist


TOPIC = '/cmd_vel'

def send_twist(pub, linear=0.0, angular=0.0, duration=3.0):
    msg = Twist()
    msg.linear.x = float(linear)
    msg.angular.z = float(angular)
    end = time.time() + duration
    while time.time() < end and rclpy.ok():
        pub.publish(msg)
        time.sleep(0.1)
    # stop
    stop = Twist()
    pub.publish(stop)
    time.sleep(0.2)

def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else 'forward'
    rclpy.init()
    node = Node('drive_robot')
    pub = node.create_publisher(Twist, TOPIC, 10)
    # wait for bridge subscriber
    time.sleep(1.0)
    print(f'Driving: {mode} on {TOPIC}')

    if mode == 'forward':
        send_twist(pub, linear=0.3, angular=0.0, duration=3.0)
    elif mode == 'back':
        send_twist(pub, linear=-0.3, angular=0.0, duration=3.0)
    elif mode == 'left':
        send_twist(pub, linear=0.0, angular=0.8, duration=3.0)
    elif mode == 'right':
        send_twist(pub, linear=0.0, angular=-0.8, duration=3.0)
    elif mode == 'circle':
        send_twist(pub, linear=0.3, angular=0.5, duration=5.0)
    elif mode == 'square':
        for i in range(4):
            print(f'side {i+1}/4 forward')
            send_twist(pub, linear=0.3, angular=0.0, duration=3.3)  # ~1m
            print(f'corner {i+1}/4 turn')
            send_twist(pub, linear=0.0, angular=0.8, duration=2.0)  # ~90deg
    else:
        print('Unknown mode. Use: forward|back|left|right|circle|square')
    print('Done, sent stop.')
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
