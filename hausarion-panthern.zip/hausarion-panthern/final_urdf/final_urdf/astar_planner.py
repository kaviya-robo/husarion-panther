#!/usr/bin/env python3
"""A* path planner for the final_urdf robot.

Builds a 2D occupancy grid from a known static obstacle list, inflates
obstacles by a safety margin (robot radius), runs A* from start to goal,
and publishes:
  /map           (nav_msgs/OccupancyGrid, transient_local latched)
  /planned_path  (nav_msgs/Path)
  /path_markers  (visualization_msgs/MarkerArray: start, goal, obstacles)

Goal is configurable via ROS 2 parameters (goal_x, goal_y).
Replanning: publish std_msgs/Empty on /replan to recompute A* from the
robot's current /odom pose to the (possibly updated) goal parameters.
"""

import heapq
import math

import rclpy
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy

from geometry_msgs.msg import Point, PoseStamped
from nav_msgs.msg import OccupancyGrid, Odometry, Path
from std_msgs.msg import Empty, Header
from visualization_msgs.msg import Marker, MarkerArray


# ----------------------------------------------------------------------------
# A* core (pure functions, no ROS dependency -> easy to unit test)
# ----------------------------------------------------------------------------

# 8-connected moves: (dx, dy, cost)
_MOVES = [
    (1, 0, 1.0), (-1, 0, 1.0), (0, 1, 1.0), (0, -1, 1.0),
    (1, 1, math.sqrt(2)), (1, -1, math.sqrt(2)),
    (-1, 1, math.sqrt(2)), (-1, -1, math.sqrt(2)),
]


def octile(a, b):
    """Octile distance heuristic (admissible for 8-connected grids)."""
    dx = abs(a[0] - b[0])
    dy = abs(a[1] - b[1])
    return max(dx, dy) + (math.sqrt(2) - 1.0) * min(dx, dy)


def astar(occupied, width, height, start, goal):
    """A* on a boolean occupancy grid.

    Returns a list of (col, row) cells from start to goal (inclusive),
    or None if no path exists. `occupied` is a flat row-major list.
    """
    def idx(c):
        return c[1] * width + c[0]

    def inside(c):
        return 0 <= c[0] < width and 0 <= c[1] < height

    if not inside(start) or not inside(goal):
        return None
    if occupied[idx(start)] or occupied[idx(goal)]:
        return None

    open_heap = [(octile(start, goal), 0.0, start)]
    came_from = {}
    g_score = {start: 0.0}
    closed = set()

    while open_heap:
        _, g, current = heapq.heappop(open_heap)
        if current in closed:
            continue
        if current == goal:
            # Reconstruct path.
            path = [current]
            while current in came_from:
                current = came_from[current]
                path.append(current)
            path.reverse()
            return path
        closed.add(current)
        for dx, dy, cost in _MOVES:
            nxt = (current[0] + dx, current[1] + dy)
            if not inside(nxt) or occupied[idx(nxt)] or nxt in closed:
                continue
            # Prevent corner cutting through blocked diagonal corners.
            if dx != 0 and dy != 0:
                if occupied[idx((current[0] + dx, current[1]))] or \
                   occupied[idx((current[0], current[1] + dy))]:
                    continue
            ng = g + cost
            if ng < g_score.get(nxt, math.inf):
                g_score[nxt] = ng
                came_from[nxt] = current
                heapq.heappush(open_heap, (ng + octile(nxt, goal), ng, nxt))
    return None


def line_of_sight(occupied, width, height, a, b):
    """Bresenham line-of-sight check between two cells (for smoothing)."""
    x0, y0 = a
    x1, y1 = b
    dx = abs(x1 - x0)
    dy = abs(y1 - y0)
    sx = 1 if x0 < x1 else -1
    sy = 1 if y0 < y1 else -1
    err = dx - dy
    while True:
        if occupied[y0 * width + x0]:
            return False
        if (x0, y0) == (x1, y1):
            return True
        e2 = 2 * err
        if e2 > -dy:
            err -= dy
            x0 += sx
        if e2 < dx:
            err += dx
            y0 += sy


def smooth_path(occupied, width, height, path):
    """Greedy line-of-sight smoothing: skip intermediate cells when the
    straight segment between anchor cells stays in free space."""
    if not path or len(path) < 3:
        return path
    smoothed = [path[0]]
    anchor = 0
    for i in range(2, len(path)):
        if line_of_sight(occupied, width, height, path[anchor], path[i]):
            continue
        smoothed.append(path[i - 1])
        anchor = i - 1
    smoothed.append(path[-1])
    return smoothed


def parse_obstacles(specs):
    """Parse obstacle strings into dicts.

    Formats: 'box:x,y,sx,sy' or 'cyl:x,y,radius'.
    Example: 'box:1.5,0.8,1.2,0.6', 'cyl:2.8,2.8,0.5'.
    """
    obstacles = []
    for spec in specs:
        parts = spec.strip().split(':')
        if len(parts) != 2:
            continue
        kind, vals = parts
        nums = [float(v) for v in vals.split(',')]
        if kind == 'box' and len(nums) == 4:
            obstacles.append({'kind': 'box', 'x': nums[0], 'y': nums[1],
                              'sx': nums[2], 'sy': nums[3]})
        elif kind == 'cyl' and len(nums) == 3:
            obstacles.append({'kind': 'cyl', 'x': nums[0], 'y': nums[1],
                              'r': nums[2]})
    return obstacles


def build_grid(obstacles, origin_x, origin_y, width_m, height_m,
               resolution, inflation):
    """Rasterize obstacles (+inflation) into a flat boolean grid."""
    w = int(round(width_m / resolution))
    h = int(round(height_m / resolution))
    occupied = [False] * (w * h)
    for row in range(h):
        cy = origin_y + (row + 0.5) * resolution
        for col in range(w):
            cx = origin_x + (col + 0.5) * resolution
            for ob in obstacles:
                if ob['kind'] == 'box':
                    dx = abs(cx - ob['x']) - ob['sx'] / 2.0
                    dy = abs(cy - ob['y']) - ob['sy'] / 2.0
                    # Distance from point to rectangle (negative = inside).
                    dist = math.hypot(max(dx, 0.0), max(dy, 0.0)) + min(max(dx, dy), 0.0)
                else:  # cylinder
                    dist = math.hypot(cx - ob['x'], cy - ob['y']) - ob['r']
                if dist <= inflation:
                    occupied[row * w + col] = True
                    break
    return occupied, w, h


# ----------------------------------------------------------------------------
# ROS 2 node
# ----------------------------------------------------------------------------

class AStarPlanner(Node):
    def __init__(self):
        super().__init__('astar_planner')

        # -- Configurable parameters -------------------------------------
        self.declare_parameter('resolution', 0.1)        # m/cell
        self.declare_parameter('inflation_radius', 0.55)  # safety margin (m)
        self.declare_parameter('origin_x', -7.0)        # map origin (m)
        self.declare_parameter('origin_y', -7.0)
        self.declare_parameter('map_width', 14.0)       # meters
        self.declare_parameter('map_height', 14.0)
        self.declare_parameter('start_x', 0.0)
        self.declare_parameter('start_y', 0.0)
        self.declare_parameter('goal_x', 4.5)           # easy-to-change goal
        self.declare_parameter('goal_y', 4.5)
        # Must mirror worlds/path_planning_world.sdf obstacle poses/sizes.
        self.declare_parameter('obstacles', [
            'box:1.5,0.8,1.2,0.6',
            'box:0.2,2.6,0.6,1.4',
            'cyl:2.8,2.8,0.5',
            'box:3.6,0.6,0.8,0.8',
        ])
        self.declare_parameter('map_frame', 'map')
        self.declare_parameter('odom_topic', '/odom')

        # -- Publishers (latched map so late subscribers still get it) ---
        latched = QoSProfile(depth=1)
        latched.durability = DurabilityPolicy.TRANSIENT_LOCAL
        latched.reliability = ReliabilityPolicy.RELIABLE
        self.map_pub = self.create_publisher(OccupancyGrid, '/map', latched)
        self.path_pub = self.create_publisher(Path, '/planned_path', latched)
        self.marker_pub = self.create_publisher(MarkerArray, '/path_markers', latched)

        # -- Subscriptions: current pose (for replanning) + replan trigger
        odom_topic = self.get_parameter('odom_topic').value
        self.current_pose = None  # (x, y)
        self.create_subscription(Odometry, odom_topic, self.odom_cb, 10)
        self.create_subscription(Empty, '/replan', self.replan_cb, 10)

        # Republish map/path at 1 Hz so RViz stays in sync.
        self.create_timer(1.0, self.republish_cb)

        # Initial plan from the configured start pose.
        self.grid = None
        self.grid_w = self.grid_h = 0
        self.last_path_cells = None
        self.plan_from(self.get_parameter('start_x').value,
                       self.get_parameter('start_y').value)

    # -- Callbacks ------------------------------------------------------
    def odom_cb(self, msg):
        self.current_pose = (msg.pose.pose.position.x,
                             msg.pose.pose.position.y)

    def replan_cb(self, _msg):
        """Recompute A* from the robot's CURRENT pose to the goal."""
        if self.current_pose is None:
            self.get_logger().warn('Replan requested but no /odom yet.')
            return
        goal_x = self.get_parameter('goal_x').value
        goal_y = self.get_parameter('goal_y').value
        self.get_logger().info(
            f'Replanning from ({self.current_pose[0]:.2f}, '
            f'{self.current_pose[1]:.2f}) to ({goal_x}, {goal_y})')
        self.plan_from(self.current_pose[0], self.current_pose[1])

    def republish_cb(self):
        if self.grid is not None:
            self.map_pub.publish(self.grid_msg)
        if self.last_path_cells is not None:
            self.path_pub.publish(self.path_msg)
            self.marker_pub.publish(self.marker_msg)

    # -- Planning --------------------------------------------------------
    def world_to_cell(self, x, y):
        res = self.get_parameter('resolution').value
        ox = self.get_parameter('origin_x').value
        oy = self.get_parameter('origin_y').value
        return (int((x - ox) / res), int((y - oy) / res))

    def cell_to_world(self, col, row):
        res = self.get_parameter('resolution').value
        ox = self.get_parameter('origin_x').value
        oy = self.get_parameter('origin_y').value
        return (ox + (col + 0.5) * res, oy + (row + 0.5) * res)

    def plan_from(self, sx, sy):
        p = self.get_parameter
        obstacles = parse_obstacles(p('obstacles').value)
        occupied, w, h = build_grid(
            obstacles, p('origin_x').value, p('origin_y').value,
            p('map_width').value, p('map_height').value,
            p('resolution').value, p('inflation_radius').value)
        self.grid_w, self.grid_h = w, h

        start = self.world_to_cell(sx, sy)
        goal = self.world_to_cell(p('goal_x').value, p('goal_y').value)
        # Clamp into grid bounds.
        start = (min(max(start[0], 0), w - 1), min(max(start[1], 0), h - 1))
        goal = (min(max(goal[0], 0), w - 1), min(max(goal[1], 0), h - 1))

        cells = astar(occupied, w, h, start, goal)
        if cells is None:
            self.get_logger().error('A* failed: no collision-free path found!')
            return
        cells = smooth_path(occupied, w, h, cells)
        self.get_logger().info(
            f'A* path found: {len(cells)} waypoints, '
            f'{len(cells) * p("resolution").value:.2f} m approx.')

        frame = p('map_frame').value
        stamp = self.get_clock().now().to_msg()

        # OccupancyGrid message.
        grid = OccupancyGrid()
        grid.header = Header(stamp=stamp, frame_id=frame)
        grid.info.resolution = p('resolution').value
        grid.info.width = w
        grid.info.height = h
        grid.info.origin.position.x = p('origin_x').value
        grid.info.origin.position.y = p('origin_y').value
        grid.info.origin.orientation.w = 1.0
        grid.data = [100 if c else 0 for c in occupied]
        self.grid = occupied
        self.grid_msg = grid

        # Path message (sequence of x, y waypoints).
        path = Path()
        path.header = Header(stamp=stamp, frame_id=frame)
        for col, row in cells:
            wx, wy = self.cell_to_world(col, row)
            pose = PoseStamped()
            pose.header = Header(stamp=stamp, frame_id=frame)
            pose.pose.position.x = wx
            pose.pose.position.y = wy
            pose.pose.orientation.w = 1.0
            path.poses.append(pose)
        self.last_path_cells = cells
        self.path_msg = path

        # Markers: start (green), goal (red), obstacles (blue).
        markers = MarkerArray()
        sx_w, sy_w = self.cell_to_world(*cells[0])
        gx_w, gy_w = self.cell_to_world(*cells[-1])
        markers.markers.append(self.make_marker(
            0, 'start', sx_w, sy_w, 0.0, 1.0, 0.0))
        markers.markers.append(self.make_marker(
            1, 'goal', gx_w, gy_w, 1.0, 0.0, 0.0))
        for i, ob in enumerate(obstacles):
            m = Marker()
            m.header.frame_id = frame
            m.ns = 'obstacles'
            m.id = 10 + i
            m.action = Marker.ADD
            if ob['kind'] == 'box':
                m.type = Marker.CUBE
                m.scale.x, m.scale.y, m.scale.z = ob['sx'], ob['sy'], 0.8
            else:
                m.type = Marker.CYLINDER
                m.scale.x = m.scale.y = 2 * ob['r']
                m.scale.z = 0.9
            m.pose.position.x = ob['x']
            m.pose.position.y = ob['y']
            m.pose.position.z = 0.4
            m.pose.orientation.w = 1.0
            m.color.r, m.color.g, m.color.b, m.color.a = 0.2, 0.4, 1.0, 0.6
            m.lifetime.sec = 0
            markers.markers.append(m)
        self.marker_msg = markers

        self.map_pub.publish(grid)
        self.path_pub.publish(path)
        self.marker_pub.publish(markers)

    @staticmethod
    def make_marker(mid, ns, x, y, r, g, b):
        m = Marker()
        m.header.frame_id = 'map'
        m.ns = ns
        m.id = mid
        m.type = Marker.SPHERE
        m.action = Marker.ADD
        m.pose.position.x = x
        m.pose.position.y = y
        m.pose.position.z = 0.2
        m.pose.orientation.w = 1.0
        m.scale.x = m.scale.y = m.scale.z = 0.3
        m.color.r, m.color.g, m.color.b, m.color.a = r, g, b, 1.0
        m.lifetime.sec = 0
        return m


def main(args=None):
    rclpy.init(args=args)
    node = AStarPlanner()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    if rclpy.ok():
        rclpy.shutdown()


if __name__ == '__main__':
    main()
