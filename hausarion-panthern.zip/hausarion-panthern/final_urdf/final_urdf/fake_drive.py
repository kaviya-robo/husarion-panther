#!/usr/bin/env python3

import math

import rclpy
from rclpy.node import Node

from geometry_msgs.msg import Twist
from sensor_msgs.msg import JointState
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped


class FakeDrive(Node):

    def __init__(self):
        super().__init__('fake_drive')

        self.cmd_sub = self.create_subscription(
            Twist,
            '/cmd_vel',
            self.cmd_callback,
            10
        )

        self.joint_pub = self.create_publisher(
            JointState,
            '/joint_states',
            10
        )

        self.tf_broadcaster = TransformBroadcaster(self)

        self.timer = self.create_timer(0.02, self.update)

        # Robot dimensions
        self.wheel_radius = 0.05
        self.wheel_base = 0.25

        # Robot pose
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0

        # Wheel positions
        self.wheel_positions = {
            'front_left': 0.0,
            'back_left': 0.0,
            'front_right': 0.0,
            'back_right': 0.0
        }

        self.linear = 0.0
        self.angular = 0.0

        self.last_time = self.get_clock().now()

    def cmd_callback(self, msg):
        self.linear = msg.linear.x
        self.angular = msg.angular.z

    def update(self):

        now = self.get_clock().now()
        dt = (now - self.last_time).nanoseconds / 1e9
        self.last_time = now

        if dt <= 0:
            return

        # Differential-drive wheel velocities
        v_left = (
            self.linear -
            self.angular * self.wheel_base / 2.0
        )

        v_right = (
            self.linear +
            self.angular * self.wheel_base / 2.0
        )

        left_w = v_left / self.wheel_radius
        right_w = v_right / self.wheel_radius

        # Update wheel angles
        self.wheel_positions['front_left'] += left_w * dt
        self.wheel_positions['back_left'] += left_w * dt

        self.wheel_positions['front_right'] += right_w * dt
        self.wheel_positions['back_right'] += right_w * dt

        # Update robot position
        self.x += self.linear * math.cos(self.theta) * dt
        self.y += self.linear * math.sin(self.theta) * dt
        self.theta += self.angular * dt

        # Publish wheel states
        joint_msg = JointState()
        joint_msg.header.stamp = now.to_msg()

        joint_msg.name = [
            'front_left',
            'back_left',
            'front_right',
            'back_right'
        ]

        joint_msg.position = [
            self.wheel_positions['front_left'],
            self.wheel_positions['back_left'],
            self.wheel_positions['front_right'],
            self.wheel_positions['back_right']
        ]

        self.joint_pub.publish(joint_msg)

        # Publish base TF
        transform = TransformStamped()

        transform.header.stamp = now.to_msg()
        transform.header.frame_id = 'dummy_link'
        transform.child_frame_id = 'base_link'

        transform.transform.translation.x = self.x
        transform.transform.translation.y = self.y
        transform.transform.translation.z = 0.0

        transform.transform.rotation.z = math.sin(self.theta / 2.0)
        transform.transform.rotation.w = math.cos(self.theta / 2.0)

        self.tf_broadcaster.sendTransform(transform)


def main(args=None):

    rclpy.init(args=args)

    node = FakeDrive()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
