#!/usr/bin/env python3
"""Path follower (controller) for the final_urdf robot.

Subscribes to the A* /planned_path, tracks the robot pose via /odom,
and publishes geometry_msgs/Twist on /cmd_vel (bridged to Gazebo):
  - Select the first waypoint beyond a lookahead distance.
  - linear.x scaled by heading error; angular.z = kp * heading error.
  - Slow down inside slow_radius of the goal; stop within goal_tolerance.

Safety (/scan LiDAR):
  - If any range in the forward sector is below safety_distance, stop
    immediately and publish std_msgs/Empty on /replan (throttled) so the
    planner recomputes A* from the current pose.
"""

import math

import rclpy
from rclpy.node import Node

from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry, Path
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Empty


def yaw_from_quaternion(q):
    """Extract yaw (rad) from a geometry_msgs Quaternion."""
    siny = 2.0 * (q.w * q.z + q.x * q.y)
    cosy = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny, cosy)


def angle_wrap(a):
    """Wrap angle to [-pi, pi]."""
    while a > math.pi:
        a -= 2.0 * math.pi
    while a < -math.pi:
        a += 2.0 * math.pi
    return a


class PathFollower(Node):
    def __init__(self):
        super().__init__('path_follower')

        # -- Configurable parameters -------------------------------------
        self.declare_parameter('cmd_vel_topic', '/cmd_vel')
        self.declare_parameter('odom_topic', '/odom')
        self.declare_parameter('scan_topic', '/scan')
        self.declare_parameter('path_topic', '/planned_path')
        self.declare_parameter('lookahead_dist', 0.4)   # m
        self.declare_parameter('max_linear_vel', 0.35)  # m/s
        self.declare_parameter('max_angular_vel', 1.0)  # rad/s
        self.declare_parameter('angular_gain', 1.8)     # P gain on heading err
        self.declare_parameter('goal_tolerance', 0.25)  # m: stop radius
        self.declare_parameter('slow_radius', 1.0)      # m: begin slowdown
        self.declare_parameter('safety_distance', 0.6)  # m: LiDAR stop
        self.declare_parameter('front_sector', 0.5)     # rad half-width
        self.declare_parameter('replan_cooldown', 3.0)  # s between /replan
        self.declare_parameter('control_rate', 10.0)    # Hz

        p = self.get_parameter
        self.cmd_pub = self.create_publisher(
            Twist, p('cmd_vel_topic').value, 10)
        self.replan_pub = self.create_publisher(Empty, '/replan', 10)

        self.create_subscription(Path, p('path_topic').value,
                                 self.path_cb, 10)
        self.create_subscription(Odometry, p('odom_topic').value,
                                 self.odom_cb, 10)
        self.create_subscription(LaserScan, p('scan_topic').value,
                                 self.scan_cb, 10)

        self.waypoints = []   # list of (x, y)
        self.next_idx = 0     # monotonic target index into waypoints
        self.pose = None      # (x, y, yaw)
        self.min_front = math.inf
        self.goal_reached = False
        self.last_replan_time = self.get_clock().now()
        # Escape behavior state (un-wedge when safety blocks progress).
        self.blocked_since = None   # time safety first fired (None = clear)
        self.backup_until = None    # time until which to back up + turn
        self.last_backup_time = self.get_clock().now()

        self.create_timer(1.0 / p('control_rate').value, self.control_cb)
        self.get_logger().info('Path follower ready, waiting for path + odom.')

    # -- Callbacks ------------------------------------------------------
    def path_cb(self, msg):
        new_waypoints = [(pose.pose.position.x, pose.pose.position.y)
                         for pose in msg.poses]
        # The planner republishes the latched path at 1 Hz; only treat it
        # as a NEW path (resetting goal state) when the content changed,
        # e.g. after a replan. Otherwise a reached goal would restart.
        if new_waypoints != self.waypoints:
            self.waypoints = new_waypoints
            self.next_idx = 0  # monotonic progress: never retarget backwards
            self.goal_reached = False
            self.get_logger().info(
                f'Received path with {len(self.waypoints)} waypoints.')

    def odom_cb(self, msg):
        pos = msg.pose.pose.position
        self.pose = (pos.x, pos.y,
                     yaw_from_quaternion(msg.pose.pose.orientation))

    def scan_cb(self, msg):
        """Track the closest range inside the forward sector."""
        if not msg.ranges:
            return
        angle = msg.angle_min
        closest = math.inf
        half = self.get_parameter('front_sector').value
        for r in msg.ranges:
            if abs(angle_wrap(angle)) <= half:
                if math.isfinite(r) and r < closest:
                    closest = r
            angle += msg.angle_increment
        self.min_front = closest

    # -- Control loop ----------------------------------------------------
    def stop(self):
        self.cmd_pub.publish(Twist())

    def control_cb(self):
        if self.pose is None or not self.waypoints:
            return  # waiting for data
        if self.goal_reached:
            self.stop()
            return

        p = self.get_parameter
        now = self.get_clock().now()
        x, y, yaw = self.pose
        gx, gy = self.waypoints[-1]
        goal_dist = math.hypot(gx - x, gy - y)

        # Escape: while backing up, keep reversing + turning (no other logic).
        if self.backup_until is not None and \
                now.nanoseconds < self.backup_until:
            cmd = Twist()
            cmd.linear.x = -0.25
            cmd.angular.z = 0.4
            self.cmd_pub.publish(cmd)
            return
        self.backup_until = None

        # Goal reached -> stop.
        if goal_dist <= p('goal_tolerance').value:
            self.get_logger().info(
                f'Goal reached ({goal_dist:.2f} m). Stopping.')
            self.goal_reached = True
            self.stop()
            return

        # Safety: obstacle too close ahead -> stop; if blocked persistently,
        # back up + turn briefly to un-wedge, then request a replan.
        if self.min_front <= p('safety_distance').value:
            self.get_logger().warn(
                f'Obstacle {self.min_front:.2f} m ahead: stopping.',
                throttle_duration_sec=2.0)
            self.stop()
            if self.blocked_since is None:
                self.blocked_since = now
            blocked_for = (now - self.blocked_since).nanoseconds / 1e9
            since_backup = (now - self.last_backup_time).nanoseconds / 1e9
            if blocked_for >= 2.0 and since_backup >= 6.0:
                self.get_logger().info('Blocked: backing up to un-wedge.')
                self.backup_until = self.get_clock().now().nanoseconds + \
                    int(1.5e9)
                self.last_backup_time = now
                self.blocked_since = None
                self.replan_pub.publish(Empty())
                self.last_replan_time = now
            elif (now - self.last_replan_time).nanoseconds / 1e9 >= \
                    p('replan_cooldown').value:
                self.get_logger().info('Requesting replan from current pose.')
                self.replan_pub.publish(Empty())
                self.last_replan_time = now
            return
        self.blocked_since = None

        # Select target with MONOTONIC progress: advance past waypoints
        # already reached (within lookahead), never go back to old ones.
        # (The old "first waypoint beyond lookahead" scan ping-ponged
        # around the start: once past P0 it retargeted P0 behind it.)
        lookahead = p('lookahead_dist').value
        while (self.next_idx < len(self.waypoints) - 1
               and math.hypot(self.waypoints[self.next_idx][0] - x,
                              self.waypoints[self.next_idx][1] - y) < lookahead):
            self.next_idx += 1
        tx, ty = self.waypoints[self.next_idx]

        heading_err = angle_wrap(math.atan2(ty - y, tx - x) - yaw)

        # If facing away, rotate in place first (stable for diff drive).
        if abs(heading_err) > 1.2:
            linear = 0.0
        else:
            # Scale speed by alignment and by proximity to goal.
            align = max(0.0, math.cos(heading_err))
            slow = min(1.0, goal_dist / p('slow_radius').value)
            slow = max(slow, 0.25)  # keep creeping near the goal
            linear = p('max_linear_vel').value * align * slow

        angular = max(-p('max_angular_vel').value,
                      min(p('max_angular_vel').value,
                          p('angular_gain').value * heading_err))

        cmd = Twist()
        cmd.linear.x = linear
        cmd.angular.z = angular
        self.cmd_pub.publish(cmd)


def main(args=None):
    rclpy.init(args=args)
    node = PathFollower()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    if rclpy.ok():
        rclpy.shutdown()


if __name__ == '__main__':
    main()
