"""Basic Gazebo simulation for the final_urdf robot.

Preserves the original manual-driving workflow:
  - Gazebo (empty world) + robot spawned as 'my_robot'
  - ros_gz_bridge (clock, cmd_vel incl. legacy topic, odom, tf, scan)

Manual drive still works with:
  python3 ~/drive_robot.py forward
or:
  ros2 topic pub --rate 10 /cmd_vel geometry_msgs/msg/Twist \
    "{linear: {x: 0.2}, angular: {z: 0.0}}"

Full autonomous demo (4 obstacles + A* + follower) is in
path_planning.launch.py instead.
"""

from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import EnvironmentVariable
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory

import os


def generate_launch_description():
    pkg = get_package_share_directory('final_urdf')
    pkg_parent = os.path.dirname(pkg)
    urdf_path = os.path.join(pkg, 'urdf', 'final_robot.urdf')
    bridge_path = os.path.join(pkg, 'config', 'bridge.yaml')

    with open(urdf_path, 'r') as f:
        robot_description = f.read()

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(get_package_share_directory('ros_gz_sim'),
                         'launch', 'gz_sim.launch.py')),
        launch_arguments={'gz_args': '-r empty.sdf'}.items(),
    )

    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{'robot_description': robot_description,
                     'use_sim_time': True}],
    )

    # NOTE: no joint_state_publisher (see path_planning.launch.py comment).
    spawn_robot = Node(
        package='ros_gz_sim',
        executable='create',
        output='screen',
        arguments=['-name', 'my_robot',
                   '-topic', 'robot_description',
                   '-z', '0.5'],
    )

    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        output='screen',
        arguments=['--ros-args', '-p', f'config_file:={bridge_path}'],
        parameters=[{'use_sim_time': True}],
    )

    return LaunchDescription([
        SetEnvironmentVariable(
            name='GZ_SIM_RESOURCE_PATH',
            value=[pkg_parent, ':',
                   EnvironmentVariable('GZ_SIM_RESOURCE_PATH',
                                       default_value='')]),
        SetEnvironmentVariable(
            name='IGN_GAZEBO_RESOURCE_PATH',
            value=[pkg_parent, ':',
                   EnvironmentVariable('IGN_GAZEBO_RESOURCE_PATH',
                                       default_value='')]),
        gazebo,
        robot_state_publisher,
        spawn_robot,
        bridge,
    ])
