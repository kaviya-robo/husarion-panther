"""Full multi-obstacle path planning demonstration.

Launches:
  - Gazebo Fortress with worlds/path_planning_world.sdf (4 obstacles)
  - final_urdf robot spawned as 'my_robot' (diff drive + 2D lidar)
  - ros_gz_bridge: /clock, /cmd_vel, /odom, /tf, /scan
  - map -> odom static TF (odom frame == world frame; robot spawns at 0,0)
  - astar_planner node (occupancy grid + A* + /planned_path + markers)
  - path_follower node (/cmd_vel controller with LiDAR safety + replan)
  - RViz2 with path_planning.rviz (optional, 'rviz:=false' to disable)

Run:
  ros2 launch final_urdf path_planning.launch.py
  ros2 launch final_urdf path_planning.launch.py goal_x:=3.0 goal_y:=-2.0
  ros2 launch final_urdf path_planning.launch.py rviz:=false  # headless
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.actions import SetEnvironmentVariable
from launch.conditions import IfCondition, UnlessCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import EnvironmentVariable, LaunchConfiguration
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory

import os


def generate_launch_description():
    pkg = get_package_share_directory('final_urdf')
    pkg_parent = os.path.dirname(pkg)
    urdf_path = os.path.join(pkg, 'urdf', 'final_robot.urdf')
    world_path = os.path.join(pkg, 'worlds', 'path_planning_world.sdf')
    bridge_path = os.path.join(pkg, 'config', 'bridge.yaml')
    rviz_path = os.path.join(pkg, 'config', 'path_planning.rviz')

    with open(urdf_path, 'r') as f:
        robot_description = f.read()

    # Launch arguments: goal is easy to change from the command line.
    goal_x_arg = DeclareLaunchArgument('goal_x', default_value='4.5')
    goal_y_arg = DeclareLaunchArgument('goal_y', default_value='4.5')
    rviz_arg = DeclareLaunchArgument('rviz', default_value='true')
    # 'headless' runs only the Gazebo server (no GUI). Default true:
    # RViz is the visualization for this demo and the GUI wastes CPU.
    # Set to 'false' to also open the Gazebo GUI.
    headless_arg = DeclareLaunchArgument('headless', default_value='true')

    # Obstacles MUST mirror worlds/path_planning_world.sdf.
    # Format: 'box:x,y,size_x,size_y' or 'cyl:x,y,radius'.
    obstacles = ['box:1.5,0.8,1.2,0.6',
                 'box:0.2,2.6,0.6,1.4',
                 'cyl:2.8,2.8,0.5',
                 'box:3.6,0.6,0.8,0.8']

    gazebo_server = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(get_package_share_directory('ros_gz_sim'),
                         'launch', 'gz_sim.launch.py')),
        launch_arguments={'gz_args': ['-s -r "', world_path, '"']}.items(),
        condition=IfCondition(LaunchConfiguration('headless')),
    )

    gazebo_gui = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(get_package_share_directory('ros_gz_sim'),
                         'launch', 'gz_sim.launch.py')),
        launch_arguments={'gz_args': ['-r "', world_path, '"']}.items(),
        condition=UnlessCondition(LaunchConfiguration('headless')),
    )

    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{'robot_description': robot_description,
                     'use_sim_time': True}],
    )

    # NOTE: no joint_state_publisher here. The DiffDrive plugin does not
    # publish joint states, and an unconfigured joint_state_publisher emits
    # invalid (empty) JointState messages that spam robot_state_publisher
    # with errors. robot_state_publisher publishes wheel frames at zero,
    # which is sufficient for TF/RViz; Gazebo itself animates the wheels.
    spawn_robot = Node(
        package='ros_gz_sim',
        executable='create',
        output='screen',
        arguments=['-name', 'my_robot',
                   '-topic', 'robot_description',
                   '-x', '0', '-y', '0', '-z', '0.38'],
    )

    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        output='screen',
        arguments=['--ros-args', '-p', f'config_file:={bridge_path}'],
        parameters=[{'use_sim_time': True}],
    )

    # odom frame coincides with the world frame (spawn at 0,0 yaw 0).
    map_to_odom = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        output='screen',
        arguments=['--x', '0', '--y', '0', '--z', '0',
                   '--roll', '0', '--pitch', '0', '--yaw', '0',
                   '--frame-id', 'map',
                   '--child-frame-id', 'odom'],
    )

    planner = Node(
        package='final_urdf',
        executable='astar_planner.py',
        output='screen',
         parameters=[{'resolution': 0.1,
                      'inflation_radius': 0.75,
                     'origin_x': -7.0,
                     'origin_y': -7.0,
                     'map_width': 14.0,
                     'map_height': 14.0,
                     'start_x': 0.0,
                     'start_y': 0.0,
                     'goal_x': LaunchConfiguration('goal_x'),
                     'goal_y': LaunchConfiguration('goal_y'),
                     'obstacles': obstacles,
                     'map_frame': 'map',
                     'odom_topic': '/odom',
                     'use_sim_time': True}],
    )

    follower = Node(
        package='final_urdf',
        executable='path_follower.py',
        output='screen',
        parameters=[{'cmd_vel_topic': '/cmd_vel',
                     'odom_topic': '/odom',
                     'scan_topic': '/scan',
                     'path_topic': '/planned_path',
                      'lookahead_dist': 0.4,
                      'max_linear_vel': 0.35,
                      'max_angular_vel': 0.6,
                      'angular_gain': 1.2,
                     'goal_tolerance': 0.25,
                     'slow_radius': 1.0,
                     'safety_distance': 0.6,
                     'front_sector': 0.5,
                     'replan_cooldown': 3.0,
                     'control_rate': 10.0,
                     'use_sim_time': True}],
    )

    rviz = Node(
        package='rviz2',
        executable='rviz2',
        output='screen',
        arguments=['-d', rviz_path],
        condition=IfCondition(LaunchConfiguration('rviz')),
    )

    return LaunchDescription([
        SetEnvironmentVariable(
            name='GZ_SIM_RESOURCE_PATH',
            value=[pkg_parent, ':',
                   EnvironmentVariable('GZ_SIM_RESOURCE_PATH',
                                       default_value='')]),
        SetEnvironmentVariable(
            name='IGN_GAZEBO_RESOURCE_PATH',
            value=[pkg_parent, ':',
                   EnvironmentVariable('IGN_GAZEBO_RESOURCE_PATH',
                                       default_value='')]),
        goal_x_arg,
        goal_y_arg,
        rviz_arg,
        headless_arg,
        gazebo_server,
        gazebo_gui,
        robot_state_publisher,
        spawn_robot,
        bridge,
        map_to_odom,
        planner,
        follower,
        rviz,
    ])
