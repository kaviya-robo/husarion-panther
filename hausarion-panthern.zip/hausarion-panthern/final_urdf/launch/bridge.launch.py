from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    """Bridge ROS /cmd_vel commands to the Gazebo robot controller."""
    return LaunchDescription([
        Node(
            package='ros_gz_bridge',
            executable='parameter_bridge',
            name='cmd_vel_bridge',
            arguments=[
                '/model/my_robot/cmd_vel@geometry_msgs/msg/Twist@gz.msgs.Twist',
            ],
            output='screen',
        ),
    ])
